import sys, os
sys.path.append(os.getcwd()+'../WebFramwork/')
import time
import ReadTestcasesFromExcel

def testcaseStatus(expectedVal):
    time.sleep(WAIT_TIME_USER_VIEW)
    html = driver.page_source
    if expectedVal in html:
        return "PASS"
    else:
        return "FAIL"

def login_testcase_type2(tcNumber, ui_screen, tc_description, username, password, expected, numberOfIterations):


    tc_data = []

    ##################### Test Report Info START #################

    tc_data.append(str(tcNumber))     #Testcase Number
    tc_data.append(ui_screen)     #Testcase description
    tc_data.append(tc_description)     #Testcase description
    tc_data.append("username: "+username+"<br>password: "+str(password))     #Testcase Inputs
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################
    for indx in range(0,numberOfIterations):
        #Enter the user name
        time.sleep(WAIT_TIME_USER_VIEW)
        clickOnUserName = driver.find_element_by_id("id_username")
        clickOnUserName.clear()
        clickOnUserName.send_keys(username)
        time.sleep(WAIT_TIME_USER_VIEW)

        #Enter the user name
        clickOnPassword = driver.find_element_by_id("id_password")
        clickOnPassword.clear()
        clickOnPassword.send_keys(password)
        time.sleep(WAIT_TIME_USER_VIEW)

        loginButton = driver.find_element_by_id("login_button")
        loginButton.click()
        time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################

def login_testcase_type1(tcNumber, ui_screen, tc_description, username, password, expected):

    tc_data = []

    ##################### Test Report Info START #################

    tc_data.append(str(tcNumber))     #Testcase Number
    tc_data.append(ui_screen)     #Testcase description
    tc_data.append(tc_description)     #Testcase description
    tc_data.append("username: "+username+"<br>password: "+str(password))     #Testcase Inputs
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################

    #Enter the user name
    time.sleep(WAIT_TIME_USER_VIEW)
    clickOnUserName = driver.find_element_by_id("id_username")
    clickOnUserName.clear()
    clickOnUserName.send_keys(username)
    time.sleep(WAIT_TIME_USER_VIEW)

    #Enter the user name
    clickOnPassword = driver.find_element_by_id("id_password")
    clickOnPassword.clear()
    clickOnPassword.send_keys(password)
    time.sleep(WAIT_TIME_USER_VIEW)

    loginButton = driver.find_element_by_id("login_button")
    loginButton.click()
    time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################

############################ HOME PAGE ######################################

def homepage_testcase2(tcNumber,  ui_screen, tc_description, oldpasword, password1, password2, expected):

    tc_data = []

    ##################### Test Report Info START #################

    tc_data.append(str(tcNumber))     #Testcase Number
    tc_data.append(ui_screen)     #Testcase description
    tc_data.append(tc_description)     #Testcase description
    tc_data.append("oldpassword: "+oldpasword+"<br>new password1: "+str(password1)+"<br>new password2: "+str(password2))     #Testcase Inputs
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################

    #Enter the user name
    time.sleep(WAIT_TIME_USER_VIEW)
    clickOnUserName = driver.find_element_by_id("id_old_password")
    clickOnUserName.clear()
    clickOnUserName.send_keys(oldpasword)
    time.sleep(WAIT_TIME_USER_VIEW)

    #Enter the user name
    clickOnPassword = driver.find_element_by_id("id_new_password1")
    clickOnPassword.clear()
    clickOnPassword.send_keys(password1)
    time.sleep(WAIT_TIME_USER_VIEW)

    #Enter the user name
    clickOnPassword = driver.find_element_by_id("id_new_password2")
    clickOnPassword.clear()
    clickOnPassword.send_keys(password2)
    time.sleep(WAIT_TIME_USER_VIEW)

    loginButton = driver.find_element_by_xpath('//*[@id="content-main"]/form/div/div/input')
    loginButton.click()
    time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################

def run_dau_gui_tests():

    noOfTestcases = len(testcaseData)
    tc_exec_count = 0

    for tc_data in testcaseData:
        tc_exec_count = tc_exec_count+1
        print("Testcase execution in progress. Currently ("+str(tc_exec_count)+"/"+str(noOfTestcases)+") testcases executed.")
        if len(tc_data) == 1:
            testReport_data.append(tc_data[0])
        elif len(tc_data) == 6:

            tc_number = int(float(tc_data[0])) #fetch testcase number
            tc_UIType = tc_data[1] # UI screen type
            tc_description = tc_data[2] # UI screen type
            getInputData = tc_data[3].split(",") #Gets the input data
            tc_expectedVal = tc_data[4] # get expected value
            testcase_type_number = tc_data[5] #fetch testcase type

            if testcase_type_number == "login_testcase_type1":
                username = getInputData[0].split(":")[1].strip()
                password = getInputData[1].split(":")[1].strip()
                login_testcase_type1(tc_number,tc_UIType,tc_description,username,password,tc_expectedVal)

            elif testcase_type_number == "login_testcase_type2":
                username = getInputData[0].split(":")[1].strip()
                password = getInputData[1].split(":")[1].strip()
                numberOfIter = int(float(getInputData[2].split(":")[1].strip()))
                login_testcase_type2(tc_number,tc_UIType,tc_description,username,password,tc_expectedVal, numberOfIter)

            elif testcase_type_number == "homepage_testcase2":
                old_password = getInputData[0].split(":")[1].strip()
                password1 = getInputData[1].split(":")[1].strip()
                password2 = getInputData[2].split(":")[1].strip()
                homepage_testcase2(tc_number,tc_UIType,tc_description,old_password,password1, password2, tc_expectedVal)

def dau_gui_testcases(driver_local, WAIT_TIME_USER_VIEW_LOCAL):

    #### File Global section #####
    global driver
    global WAIT_TIME_USER_VIEW
    global testReport_data
    global testcaseData

    driver = driver_local
    WAIT_TIME_USER_VIEW = WAIT_TIME_USER_VIEW_LOCAL
    testReport_data = []

    ######### Read Testcases from Excel sheet ##########
    testcaseData = ReadTestcasesFromExcel.readTestcaseData()

    #########  GUI tests ##########
    run_dau_gui_tests()

    #########  GUI Tests end ##########

    return testReport_data
