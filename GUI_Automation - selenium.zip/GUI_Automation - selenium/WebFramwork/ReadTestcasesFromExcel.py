import xlrd, os


def readTestcaseData():
    #Read workbook
    workbookPtr = xlrd.open_workbook(os.getcwd()+"\..\TestInputs\DAU_GUITestcases.xlsx")
    sheet = workbookPtr.sheet_by_index(0)
    numOfRows = sheet.nrows
    rowIndx = 1
    testcaseData = []

    while rowIndx < numOfRows:
        testcaseData_temp = []
        row_data = sheet.row_values(rowIndx)
        for indx in row_data:
            data = str(indx).strip()
            if len(data) > 0:
                data = str(data.replace("\n","<br>")).strip()
                testcaseData_temp.append(data)
        rowIndx = rowIndx+1
        testcaseData.append(testcaseData_temp)

    return testcaseData


