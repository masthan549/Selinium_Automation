import sys, time, webbrowser, os
from datetime import datetime
from selenium import webdriver
from testcases import dau_gui_testcases

def dauHTMLTestResultFileHeader():
    global outputData

    outputData = """
    <html style="background-color: #e6e6e6;">
        <title> DAU Test Results</title>
        <br><h1 align="center">DAU GUI Automated Test Results: """+str(datetime.now())+"""
        <body>
            <br><br><table border=1 style="width:95%;" align="center">
                 <tr style="font-family: Arial, Helvetica, sans-serif;border-style:solid;background-color: #5cacee;">
                   <th width="5%" style="padding:2px;">Testcase Number</th>
                   <th width="10%">UI Screen</th>                   
                   <th width="30%">Testcase Description</th>
                   <th width="20%">Inputs Given</th>
                   <th width="15%">Expected</th>
                   <th width="15%">Actual</th>
                   <th width="5%">Result</th>
                 </tr>
                 """+str(testCase_data)+"""
            </table>
        </body>
    </html>
    """

############### MAIN #######################################

# ******* Global constants START***********
SERVER_IP = "127.0.0.1"
PORT = "8000"
URL = "http://"+str(SERVER_IP)+":"+str(PORT)
BROWSER_PATH = "C:\\vmshare\\workspace\\DAU_2\\dau_gui\\GUI_Automation\\chromedriver.exe"
WAIT_TIME_REQ_RESPONSE = 2
WAIT_TIME_USER_VIEW = 0
testCase_data = ""
# ******* Global constants END ***********

timenow = str(datetime.now())
timenow = timenow.replace("-","")
timenow = timenow.replace(":","")
timenow = timenow.replace(".","")
timenow = timenow.replace(" ","")

TestResultsFile = r"TestResult_"+str(timenow)+".html"
time.sleep(WAIT_TIME_USER_VIEW)

######## Write the output to file #######
directory = os.getcwd()+"/TestResults/"
if not os.path.exists(directory):
    os.makedirs(directory)

Html_file= open(directory+"/"+TestResultsFile,"w")
outputData = ""

#Open web browser
driver = webdriver.Chrome(BROWSER_PATH)

driver.implicitly_wait(WAIT_TIME_REQ_RESPONSE)
driver.get(URL)

#Wait for WAIT_TIME_REQ_RESPONSE sec to open the browser and connect to server
driver.implicitly_wait(WAIT_TIME_REQ_RESPONSE)
driver.maximize_window()

#Wait time for maximizing the window
driver.implicitly_wait(1)

###################  Testcases main call ################

testReport_data = dau_gui_testcases(driver, WAIT_TIME_USER_VIEW)
#testReport_data=""

###################  Writre results into test report ######################
for indx_tc_data in testReport_data:

    if len(indx_tc_data) == 7:
        tcNumber = "<td style=\"padding:3px;\">"+ str(indx_tc_data[0])+"</td>"
        UIScreen = "<td>"+indx_tc_data[1]+"</td>"
        TCDescription = "<td>"+indx_tc_data[2]+"</td>"
        inputsGiven = "<td>"+indx_tc_data[3]+"</td>"
        ExpectedVal = "<td>"+indx_tc_data[4]+"</td>"
        ActualVal = "<td>"+indx_tc_data[5]+"</td>"

        Tc_status = ""
        if indx_tc_data[6] == "PASS":
            Tc_status = "<td style=\"background-color: #008000;\">"+indx_tc_data[6]+"</td>"
        else:
            Tc_status = "<td style=\"background-color: #FF0000;\">"+indx_tc_data[6]+"</td>"

        testCase_data = testCase_data+"<tr style=\"text-align:center;\">"+tcNumber+UIScreen+TCDescription+inputsGiven+ExpectedVal+ActualVal+Tc_status+"</tr>"
    else:
        testCase_data = testCase_data + "<tr><td  align=\"center\" colspan=\"7\" style=\"padding:5px;background-color: #90EE90;\">"+str(indx_tc_data)+"</td></tr>"

dauHTMLTestResultFileHeader()
driver.close()
if len(outputData) == 0:
   Html_file.write("<h1>Test Results not available")
else:
    Html_file.write(outputData)
Html_file.close()

webbrowser.open_new_tab(directory+'\\'+TestResultsFile)
