selenium:
========
1. Download crome supported version driver from "http://chromedriver.storage.googleapis.com/index.html?path=80.0.3987.16/"
2. Istall selenium "pip install selenium" and supported packages
3. Make sure you have written testcases in Excel sheet "DAU_GUITestcases.xlsx" and excel sheet placed at "DAU_GUIAutomation\TestInputs" folder.
