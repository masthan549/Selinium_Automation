
pyautogui:
_________

1. Install pyautogui using command "py -m pip install pyautogui". Make sure to use Python3.x verion in your local PC.
2. Read mouse position using software "http://www.adminsehow.com/wp-content/uploads/2012/03/MousePos.exe"

selenium:
========
1. Download crome supported version driver from "http://chromedriver.storage.googleapis.com/index.html?path=80.0.3987.16/"
2. Istall selenium "pip install selenium"