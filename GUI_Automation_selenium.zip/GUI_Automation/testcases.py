
import time

def testcaseStatus(expectedVal):
    time.sleep(WAIT_TIME_USER_VIEW)
    html = driver.page_source
    if expectedVal in html:
        return "PASS"
    else:
        return "FAIL"

def login_testcase3(numberOfIterations, expected, TCNumber, info):

    tc_data = []

    ##################### Test Report Info START #################

    tc_data.append(str(TCNumber))     #Testcase Number
    tc_data.append("Invalid password entered for maintainer account more than 10 times. So maintainer account should be locked for 5min. "+"\n"+info)     #Testcase description
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################
    for indx in range(0,numberOfIterations):
        #Enter the user name
        time.sleep(WAIT_TIME_USER_VIEW)
        clickOnUserName = driver.find_element_by_id("id_username")
        clickOnUserName.clear()
        clickOnUserName.send_keys("maintainer")
        time.sleep(WAIT_TIME_USER_VIEW)

        #Enter the user name
        clickOnPassword = driver.find_element_by_id("id_password")
        clickOnPassword.clear()
        clickOnPassword.send_keys("incorrectpassword")
        time.sleep(WAIT_TIME_USER_VIEW)

        loginButton = driver.find_element_by_id("login_button")
        loginButton.click()
        time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################

def login_testcase2():

    tc_data = []
    expected = "Incorrect password"

    ##################### Test Report Info START #################

    tc_data.append("2")     #Testcase Number
    tc_data.append("Invalid password entered for admin user account")     #Testcase description
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################

    #Enter the user name
    time.sleep(WAIT_TIME_USER_VIEW)
    clickOnUserName = driver.find_element_by_id("id_username")
    clickOnUserName.clear()
    clickOnUserName.send_keys("admin")
    time.sleep(WAIT_TIME_USER_VIEW)

    #Enter the user name
    clickOnPassword = driver.find_element_by_id("id_password")
    clickOnPassword.clear()
    clickOnPassword.send_keys("incorrectpassword")
    time.sleep(WAIT_TIME_USER_VIEW)

    loginButton = driver.find_element_by_id("login_button")
    loginButton.click()
    time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################

def login_testcase1():

    tc_data = []
    expected = "User does not exist"

    ##################### Test Report Info START #################

    tc_data.append("1")     #Testcase Number
    tc_data.append("Invalid user name entered in username field during login")     #Testcase description
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################

    #Enter the user name
    time.sleep(WAIT_TIME_USER_VIEW)
    clickOnUserName = driver.find_element_by_id("id_username")
    clickOnUserName.clear()
    clickOnUserName.send_keys("invaliduser")
    time.sleep(WAIT_TIME_USER_VIEW)

    #Enter the user name
    clickOnPassword = driver.find_element_by_id("id_password")
    clickOnPassword.clear()
    clickOnPassword.send_keys("password")
    time.sleep(WAIT_TIME_USER_VIEW)

    loginButton = driver.find_element_by_id("login_button")
    loginButton.click()
    time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################

def login_test():

    #Requirement that is being tested
    reqText = "[SyRS_3097] When a GUI user logs in to the DAU Web GUI, the DAU Web GUI shall allow the user to submit a maximum of " \
              "10 unsuccessful password attempts before a 5 minute account lockout occurs."

    testReport_data.append(reqText)

    #testcase1: Enter invalid username
    login_testcase1()

    #testcase2: Enter invalid password for admin login
    login_testcase2()


    #testcase3: Enter invalid password for 1st times for maintainer account. Account doesnt get locked.
    numberOfIterations = 1
    login_testcase3(numberOfIterations, "Incorrect password", 4, "Maintainer account login Invalid attempt Number: 1")

    #testcase4: Enter invalid password for 2nd times for maintainer account. Account doesnt get locked.
    numberOfIterations = 1
    login_testcase3(numberOfIterations, "Incorrect password", 5, "Maintainer account login Invalid attempt Number: 2")

    #testcase5: Enter invalid password for 3rd times for maintainer account. Account doesnt get locked.
    numberOfIterations = 1
    login_testcase3(numberOfIterations, "Incorrect password", 6, "Maintainer account login Invalid attempt Number: 3")

    #testcase6: Enter invalid password for 8 times for maintainer account
    numberOfIterations = 8
    login_testcase3(numberOfIterations, "account is locked for 5min as you have exceeded maximum login attempts. Please try after 5min", 7, "Maintainer account login Invalid attempt Number: 11")

############################ HOME PAGE ######################################


def homepage_testcase1():

    tc_data = []
    expected = "System Status"

    ##################### Test Report Info START #################

    tc_data.append("1")     #Testcase Number
    tc_data.append("On valid username and password credentials, should be logged into DAU home page")     #Testcase description
    tc_data.append(expected)     #Expected

    ##################### Test Report Info END #################

    #Enter the user name
    time.sleep(WAIT_TIME_USER_VIEW)
    clickOnUserName = driver.find_element_by_id("id_username")
    clickOnUserName.clear()
    clickOnUserName.send_keys("admin")
    time.sleep(WAIT_TIME_USER_VIEW)

    #Enter the user name
    clickOnPassword = driver.find_element_by_id("id_password")
    clickOnPassword.clear()
    clickOnPassword.send_keys("password")
    time.sleep(WAIT_TIME_USER_VIEW)

    loginButton = driver.find_element_by_id("login_button")
    loginButton.click()
    time.sleep(WAIT_TIME_USER_VIEW)

    ##################### Test Report Info START #################

    #Read HTML and report the test status PASS/FAIL
    result = testcaseStatus(expected)
    if result == "PASS":
        tc_data.append(expected)    #Actual value
    else:
        tc_data.append("Actual value didn't match with Expected value")    #Actual value
    tc_data.append(result) #Test result status PASS/FAIL

    testReport_data.append(tc_data)
    ##################### Test Report Info END #################


def homePage_test():

    # Requirement that is being tested
    reqText = "[DAU_SyRS_1595]  If the received encrypted Username and Password are valid, the DAU shall: Activate the GUI session for the source IP address and Display the GUI Home Page"

    testReport_data.append(reqText)

    #testcase1: Enter valid username and password
    homepage_testcase1()


def dau_gui_testcases(driver_local, WAIT_TIME_USER_VIEW_LOCAL):

    #### File Global section #####
    global driver
    global WAIT_TIME_USER_VIEW
    global testReport_data

    driver = driver_local
    WAIT_TIME_USER_VIEW = WAIT_TIME_USER_VIEW_LOCAL
    testReport_data = []

    #########  login tests ##########
    login_test()

    homePage_test()

    ######### Other Tests ##########

    return testReport_data